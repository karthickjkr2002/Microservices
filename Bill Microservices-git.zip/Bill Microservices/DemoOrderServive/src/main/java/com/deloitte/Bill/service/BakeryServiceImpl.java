package com.deloitte.Bill.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.Bill.entity.Bakery;
import com.deloitte.Bill.repo.BakeryRepository;

@Service
public class BakeryServiceImpl implements BakeryService
{
	@Autowired
	BakeryRepository bakeryRepository;
	
	@Override
	public List<Bakery> getBakery() {
		// TODO Auto-generated method stub
		return bakeryRepository.findAll();
	}

	@Override
	public List<Bakery> getBake(Integer id) {
		// TODO Auto-generated method stub
		return bakeryRepository.findByRid(id);
	}
}