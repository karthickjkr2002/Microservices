package com.deloitte.Bill.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="BillDue")
public class Bakery 
{
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private Integer consId;
	private double cost;
	private String due;
	private Integer rid;
	public Bakery() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bakery(Integer consId, double cost, String due, Integer rid) {
		super();
		this.consId = consId;
		this.cost = cost;
		this.due = due;
		this.rid = rid;
	}
	public Integer getConsId() {
		return consId;
	}
	public void setConsId(Integer consId) {
		this.consId = consId;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public String getDue() {
		return due;
	}
	public void setDue(String due) {
		this.due = due;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	
	
}