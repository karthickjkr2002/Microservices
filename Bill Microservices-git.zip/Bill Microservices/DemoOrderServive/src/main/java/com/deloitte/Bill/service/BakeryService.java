package com.deloitte.Bill.service;
import java.util.List;

import com.deloitte.Bill.entity.Bakery;
public interface BakeryService 
{
	public List<Bakery> getBakery();
    public List<Bakery> getBake(Integer id);
}