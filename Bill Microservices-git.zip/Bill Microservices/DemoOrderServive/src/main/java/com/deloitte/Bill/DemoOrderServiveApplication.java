
package com.deloitte.Bill;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class DemoOrderServiveApplication {
	public static void main(String[] args) 
{
	SpringApplication.run(DemoOrderServiveApplication.class, args);
}
}