package com.deloitte.Bill.repo;
import com.deloitte.Bill.entity.Bakery;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BakeryRepository extends JpaRepository<Bakery, Integer> 
{
	 public List<Bakery> findByRid(Integer id);
}
