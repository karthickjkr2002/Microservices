package com.deloitte.orderms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
