package com.deloitte.consumer.service;

import java.util.List;

import com.deloitte.consumer.entity.Order;

public interface OrderService 
{
	public List<Order> getOrders();
	public List<Order> getOrder(Integer id);

}
