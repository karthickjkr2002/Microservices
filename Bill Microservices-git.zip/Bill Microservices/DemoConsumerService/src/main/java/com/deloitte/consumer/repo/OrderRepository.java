package com.deloitte.consumer.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deloitte.consumer.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer>
{
	public List<Order> findByRid(Integer rId);
}
