package com.deloitte.consumer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.consumer.entity.Order;
import com.deloitte.consumer.repo.OrderRepository;


@Service
public class OrderServiceImpl implements OrderService
{
	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public List<Order> getOrders()
	{
		return orderRepository.findAll();
	}
	
	@Override
	public List<Order> getOrder(Integer id) 
	{
		return orderRepository.findByRid(id);


	}

}
