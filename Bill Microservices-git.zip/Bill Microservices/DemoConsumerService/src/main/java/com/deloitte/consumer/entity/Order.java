package com.deloitte.consumer.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="ConsumerDetails")
public class Order 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer consId;
	private String firstName;
	private String lastName;
	private Integer rid;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(Integer consId, String firstName, String lastName, Integer rid) {
		super();
		this.consId = consId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.rid = rid;
	}
	public Integer getConsId() {
		return consId;
	}
	public void setConsId(Integer consId) {
		this.consId = consId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	
	
}
